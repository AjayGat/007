package com.capgemini.ttbo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ttbo.bean.BookingBean;
import com.capgemini.ttbo.bean.TrainBean;
import com.capgemini.ttbo.dao.ITrainDao;
import com.capgemini.ttbo.dao.TrainDaoImpl;
import com.capgemini.ttbo.exception.BookingException;

public class TrainServiceImpl implements ITrainService 
{
	ITrainDao itdao = new TrainDaoImpl();

/*****************************************************************
 *  - Method Name   	:retrieveTrainDetails() 
 *  - Input Parameters 	:Nothing
 *  - Return Type 		:DBConnection instance
 *  - Throws 			:------------- 
 *  - Author 			:KISHAN 
 *  - Creation Date 	:02/05/2019
 *******************************************************************/

	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() 
	{
		return itdao.retrieveTrainDetails();
	}
	
	
	/*****************************************************************
	 *  - Method Name   	: bookTicket() 
	 *  - Input Parameters 	:Nothing
	 *  - Return Type 		:ArrayList<TrainBean>
	 *  - Throws 			:BookingException
	 *  - Author 			:KISHAN 
	 *  - Creation Date 	:02/05/2019
	 *******************************************************************/

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException 
	{
		return itdao.bookTicket(bookingBean);
	}
	
	
	/*****************************************************************
	 *  - Method Name   	:validateDetails() 
	 *  - Input Parameters 	:String custId, int trainId, int noOfSeats
	 *  - Return Type 		:Boolean
	 *  - Throws 			:BookingException
	 *  - Author 			:KISHAN 
	 *  - Creation Date 	:02/05/2019
	 *******************************************************************/

	@Override
	public boolean validateDetails(String custId, int trainId, int noOfSeats) {
		// TODO Auto-generated method stub
		boolean flag = true;
		
		if(!(isCustomerIdValid(custId)))
		{
			flag = false;
		}
		if(!((trainId==1)||(trainId==2)||(trainId==3)||(trainId==4)))
		{
			flag = false;
		}
		if(noOfSeats<1)
		{
			flag = false;
		}
		
	    return flag;
	}
	public boolean isCustomerIdValid(String custId)
	{
		Pattern pattern = Pattern.compile("^[A-Z][0-9]{6}$");
		Matcher matcher = pattern.matcher(custId);
		boolean flag = matcher.matches();
		return flag;
	}
}


















