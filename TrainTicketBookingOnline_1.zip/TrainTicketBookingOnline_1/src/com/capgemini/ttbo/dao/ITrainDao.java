package com.capgemini.ttbo.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.ttbo.bean.BookingBean;
import com.capgemini.ttbo.bean.TrainBean;
import com.capgemini.ttbo.exception.BookingException;

public interface ITrainDao 
{
	ArrayList<TrainBean> retrieveTrainDetails();
	int bookTicket(BookingBean bookingBean)throws BookingException;
	
}
