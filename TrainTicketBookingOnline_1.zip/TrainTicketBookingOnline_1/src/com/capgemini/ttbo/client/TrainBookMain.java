package com.capgemini.ttbo.client;

import java.util.ArrayList;
import java.util.Scanner;

import com.capgemini.ttbo.bean.BookingBean;
import com.capgemini.ttbo.bean.TrainBean;
import com.capgemini.ttbo.exception.BookingException;
import com.capgemini.ttbo.service.ITrainService;
import com.capgemini.ttbo.service.TrainServiceImpl;

public class TrainBookMain {

	public static void main(String[] args)
	{
		
		ArrayList<TrainBean> trainBean = new ArrayList<TrainBean>();
		ITrainService its = new TrainServiceImpl();
		BookingBean bb ;
		Scanner sc =new Scanner(System.in);
		System.out.println("Welcome to Capgemini Train Booking System");
		System.out.println("Below is the List of Available trains with the specified details");
		
		while(true)
		{
			trainBean = its.retrieveTrainDetails();
			
			for(TrainBean tb : trainBean)
			{
				System.out.println(tb);
			}
			System.out.println("1. for Booking tickets");
			System.out.println("2. to exit");
			System.out.println("Please Enter Your Choice");
			String choice= sc.next();
			switch(choice)
			{
				case "1":	
							System.out.println("Please enter your Customer ID");
							String custId = sc.next();
							System.out.println("Please enter the TrainId");
							int trainId = sc.nextInt();
							System.out.println("Please enter the number of seats you want to book");
							int noOfSeats = sc.nextInt(); 
							//System.out.println("Please enter your");
							boolean flag = its.validateDetails(custId,trainId,noOfSeats);
							if(!flag)
							{
								System.err.println("Please Enter Valid Details");
							}
							else
							{
								bb = new BookingBean(custId,noOfSeats,trainId);
								try
								{
									int bookingId =its.bookTicket(bb);
									System.out.println("Your Booking is confirmed with booking Id" + bookingId);
								}
								catch(BookingException be)
								{
									System.err.println(be.getMessage());
								}
							}
					break;
				case "2":System.exit(0);
					break;
				default :System.out.println("Please enter a valid Choice");
					break;
			}
		}
	}

}
