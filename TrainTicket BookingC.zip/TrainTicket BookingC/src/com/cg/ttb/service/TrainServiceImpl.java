package com.cg.ttb.service;

import java.util.List;

import com.cg.ttb.beans.BookingBean;
import com.cg.ttb.beans.TrainBean;
import com.cg.ttb.dao.ITrainDao;
import com.cg.ttb.dao.TrainDaoImpl;
import com.cg.ttb.exception.TrainException;

public class TrainServiceImpl implements ITrainService {
	ITrainDao dao = new TrainDaoImpl();

	@Override
	public List<TrainBean> retrieveTrainDetails() throws TrainException {
		
		return dao.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws TrainException {
		// TODO Auto-generated method stub
	return dao.bookTicket(bookingbean);
	}

	

}
