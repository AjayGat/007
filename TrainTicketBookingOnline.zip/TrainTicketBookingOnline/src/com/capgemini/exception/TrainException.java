package com.capgemini.exception;

public class TrainException extends Exception {

	String message;
	public TrainException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return this.message;
	}
}
