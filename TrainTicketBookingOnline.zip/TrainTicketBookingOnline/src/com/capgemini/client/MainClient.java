package com.capgemini.client;

import java.util.List;
import java.util.Scanner;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.TrainException;
import com.capgemini.service.ITrainService;
import com.capgemini.service.TrainServiceImpl;



public class MainClient {
	static Logger logger=Logger.getRootLogger();

	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");
		ITrainService tservice = new TrainServiceImpl();
		String choice;
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("----------- Menu -------------\n");

			do {
				System.out.println("******************************");
				System.out.println("*  Please Enter Your Choice  *");
				System.out.println("*  1.Book Ticket             *");
				System.out.println("*  2.Exit                    *");
				System.out.println("******************************");

				choice = sc.next();
				switch (choice) {

				case "1":
				{
					List<TrainBean> tlist;
					try {
						tlist = tservice.retrieveTrainDetails();
						
						if (tlist.size() == 0) {
							logger.error("No trains available now please try after sometime\n");
							System.err.println("No trains available now please try after sometime\n");
						} else {
							int i =0;
							for (TrainBean t : tlist) {
								
								System.out.println(t);
							}
						}
					} catch (TrainException e) {
						logger.error("Unable to fetch list\n" + e.getMessage());
						System.err.println("Unable to fetch list\n" + e.getMessage());
					}

					
					
					while(true)
					{
						System.out.println("Please Enter Customer Id:");
						String custId = sc.next();
						if(!tservice.vallidateCustomerId(custId))
						{
							logger.error("Enter valid Customer Id It should start with A-Z and 6 digit after");
							System.err.println("Enter valid Customer Id It should start with A-Z and 6 digit after");
							continue;
						}


						else
						{
							while(true)
							{

								System.out.println("Please Enter Train Id:");
								int trainId = sc.nextInt();
								
								
								if(!tservice.vallidateTrainId(trainId) )
								{
									logger.error("Train with this id does not exist, enter again.");
									System.err.println("Train with this id does not exist, enter again.");
									continue;
								}
								else
								{
									while(true)
									{	

										System.out.println("Please Enter Number of Seats");
										int noOfSeat = sc.nextInt();
										if(!tservice.checkSeats(noOfSeat))
										{
											logger.error("No of seats should be > 0 and less thas available ");
											System.err.println("No of seats should be > 0 and less thas available ");
											continue;
										}
										else
										{
											BookingBean bookingbean = new BookingBean(noOfSeat, trainId,custId);

											try {
												int bookingid = tservice.bookTicket(bookingbean);
												System.out.println("your Booking Id is: "+bookingid+" "+"trainId: "+trainId+" "+"customerId: "+" "+custId+"  no of seats Booked: "+noOfSeat+" ");
											} 
											catch (TrainException e) {
												System.out.println(e.getMessage());
											}
											break;
										}
										
									}
									break;
								}
								
							}break;
						}
					}
				
				}
				
				case "2":
					System.exit(0);
					break;

				default:
					System.out.println("Please Enter Correct Input");
					break;
				}
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.next();
			} while (!choice.equals("0"));
		}
	}

}
