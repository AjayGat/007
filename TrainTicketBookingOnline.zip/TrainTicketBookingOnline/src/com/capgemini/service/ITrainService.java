package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.TrainException;



public interface ITrainService {

	public List<TrainBean> retrieveTrainDetails() throws TrainException;

	public int bookTicket(BookingBean bookingbean) throws TrainException;
	public boolean vallidateCustomerId(String id);
	public boolean vallidateTrainId(int trainId);
	public boolean checkSeats(int noOfSeat);
}
