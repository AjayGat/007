package com.capgemini.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.dao.ITrainDao;
import com.capgemini.dao.TrainDaoImpl;
import com.capgemini.exception.TrainException;

public class TrainServiceImpl implements ITrainService {
	ITrainDao dao = new TrainDaoImpl();

	@Override
	public List<TrainBean> retrieveTrainDetails() throws TrainException {

		return dao.retrieveTrainDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingbean) throws TrainException {

		return dao.bookTicket(bookingbean);
	}

	@Override
	public boolean vallidateCustomerId(String id) {
		String pattern = "[A-Z]{1}[0-9]{6}";
		if(Pattern.matches(pattern,id))
		{
			return true;
		}
		else 
		return false;
	}

	@Override
	public boolean vallidateTrainId(int trainId) {
		
		if(trainId>0)
			return true;
		else	
		return false;
	}

	@Override
	public boolean checkSeats(int noOfSeat) {
		
		if(noOfSeat>0)
			return true;
		else	
		return false;
	}

}
