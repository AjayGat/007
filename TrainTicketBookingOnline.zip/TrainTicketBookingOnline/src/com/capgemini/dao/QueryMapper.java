package com.capgemini.dao;

public class QueryMapper {
	public static final String RETRIVE_ALL_TRAINDETAILS="SELECT trainid,traintype,fromstop,tostop,fare,availableseats,dateofjourney from traindetails";
	public static final String GENERATE_BOOKINGID="SELECT BOOKING_ID_SEQ.NEXTVAL from DUAL";
	public static final String INSERT_BOOKING_DETAILS="INSERT INTO BOOKINGDETAILS VALUES (?,?,?,?)";
}
