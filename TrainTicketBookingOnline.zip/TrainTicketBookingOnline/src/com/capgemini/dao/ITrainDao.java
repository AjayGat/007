package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.TrainBean;
import com.capgemini.exception.TrainException;



public interface ITrainDao {

	List<TrainBean> retrieveTrainDetails() throws TrainException;

	int bookTicket(BookingBean bookingbean) throws TrainException;

	int generateBookingId()  throws TrainException;

}
