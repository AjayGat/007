package com.cg.mra.service;

import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileRechargeException;

public class AccountServiceImpl implements AccountService{

	AccountDao dao = new AccountDaoImpl();
	
	@Override
	public Account getAccountDetails(String accountId)
			throws MobileRechargeException {
		// TODO Auto-generated method stub
		return dao.getAccountDetails(accountId);
	}

	@Override
	public double rechargeAccount(String accountid, double rechargeAmount)
			throws MobileRechargeException {
		// TODO Auto-generated method stub
		return dao.rechargeAccount(accountid, rechargeAmount);
	}

	@Override
	public boolean validateAccountId(String accountId)
			throws MobileRechargeException {
		String pattern = "[0-9]{1,}";
		if(Pattern.matches(pattern,accountId+""))
			return true;
		else		
		
		return false;
	}


	
	
}
