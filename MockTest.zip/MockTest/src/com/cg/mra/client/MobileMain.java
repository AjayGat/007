package com.cg.mra.client;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MobileMain {
static AccountService service =new  AccountServiceImpl();

static Logger logger=Logger.getRootLogger();

	public static void main(String[] args) {
		
		PropertyConfigurator.configure("resources/log4j.properties");

		int choice;
		try(Scanner sc = new Scanner(System.in))
		{
			do
			{
				System.out.println("1-Account balance enquiry");
				System.out.println("2-Recharge account");
				System.out.println("3-exit");
				System.out.println("Enter choice::");
				choice = sc.nextInt();
				
				switch(choice)
				{
				
				case 1 :
					/*******************************************
					 -> Case for Account Balance Enquiry 
					 *******************************************/
					
				
					
					
					while(true)
					{
						System.out.println("enter Account id to get account details");
						String accountId=sc.next();
						try {
							if(!service.validateAccountId(accountId))
							{
								System.err.println("enter valid accountId");
								continue;
							}
							
							else
							{
								try
								{
									Account ref= service.getAccountDetails(accountId);
									logger.info(" account  details "+ref);
									System.out.println("account details "+ref);
									System.out.println("account balance :"+ref.getAccountBalance());

								}catch(MobileRechargeException e){
									System.out.println(e.getMessage());

								}
								break;

							}
						} catch (MobileRechargeException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	
					}
					
					
					
					
					break;
				case 2 :
					

					/*******************************************
					 -> Case for Recharge Account
					 *******************************************/
					
				
					
					while(true){
						System.out.println("enter the account id :");
						String accountid=sc.next();
						try {
							if(!service.validateAccountId(accountid))
							{
								System.err.println("enter valid mobileId");
								continue;
							}

									else
									{
										System.out.println("enter recharge amount ");
										double rechargeAmount=sc.nextDouble();
										try{
											double newBalance=service.rechargeAccount(accountid, rechargeAmount);
											
										}
										catch(MobileRechargeException e)
										{
											System.err.println(" Given account id doest not exist");
											System.out.println(e.getMessage());
										}
										break;
									}
						} catch (MobileRechargeException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
							}
						
					
					
					
					
					
					break;
				case 3 :
					/*******************************************
					 -> Case for Exit
					 *******************************************/
					System.exit(0);
					break;
					
					
				default:
					/*******************************************
						 -> Default case for invalid choice 
					 *******************************************/
					logger.info("Invalid choice");
					System.out.println(" you have entered invalid choice");
					
				}
				
				System.out.println("do you want to continue 1-yes 0-No");
				choice = sc.nextInt();
				
			}while(choice!=0);
			
			
			
		}
		
		
		
		
	}//main
	
	
	
	
	
}//class
