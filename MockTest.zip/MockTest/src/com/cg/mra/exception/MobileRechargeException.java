package com.cg.mra.exception;

public class MobileRechargeException extends Exception{

	String message;
	public MobileRechargeException(String message)
	{
		this.message = message;
	}
	@Override
	public String getMessage()
	{
		return this.message;
	}
	
}
