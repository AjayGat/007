package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.util.DBUtil;

public class AccountDaoImpl implements AccountDao{

	Connection con;
	Logger logger = Logger.getRootLogger();

	public AccountDaoImpl()
	{
		con = DBUtil.getConnection();
		PropertyConfigurator.configure("resources/log4j.properties");
	}


	/***************************************************************************
	 -> Function Name	    :	getAccountDetails(String accountId)
	 -> Return Type		    :	object (Account)
	 -> Throws			    :  	MobileRechargeException
	 -> Author			    :	Kavya K M
	 -> Creation Date	    :	10/06/2019
	 -> Description		    :	Account balance enquiry
	 ***************************************************************************/

	@Override
	public Account getAccountDetails(String accountId)
			throws MobileRechargeException {

		System.out.println("account id"+accountId);
		Account ac=null;

		try
		{
			PreparedStatement pst = con.prepareStatement(QueryMapper.SELECT_DETAILS_QUERY);
			pst.setString(1, accountId);
			ResultSet rs = pst.executeQuery();

			if(rs.next()){
				String id=rs.getString(1);
				String type=rs.getString(2);
				String name=rs.getString(3);
				double balance=rs.getDouble(4);
				ac= new Account(id,type,name,balance);

			}


		}catch(SQLException e){
			throw new MobileRechargeException(e.getMessage());

		}

		return ac;
	}

	
	/***************************************************************************
	 -> Function Name	    :	rechargeAccount(String accountid, double rechargeAmount)
	 -> Return Type		    :	double 
	 -> Throws			    :  	MobileRechargeException
	 -> Author			    :	Kavya K M
	 -> Creation Date	    :	10/06/2019
	 -> Description		    :	rechargeAccount
	 ***************************************************************************/
	@Override
	public double rechargeAccount(String accountid, double rechargeAmount)
			throws MobileRechargeException {

		double bal=0;
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(QueryMapper.UPDATE_BALANCE);
			pstmt.setDouble(1,rechargeAmount);
			pstmt.setString(2, accountid);
			
			int row = pstmt.executeUpdate();
			if(row > 0)
			{
				System.out.println("updated successfully");
				
			}      
			Account ac=getAccountDetails(accountid);
			bal=ac.getAccountBalance();
			
		}catch(SQLException e){
			throw new MobileRechargeException(e.getMessage());
		}
		
		
		return bal;
	}



}
