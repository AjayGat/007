package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;

public interface AccountDao {


	public Account getAccountDetails(String accountId)throws MobileRechargeException;
	public double rechargeAccount(String accountid,double rechargeAmount)throws MobileRechargeException;
}
