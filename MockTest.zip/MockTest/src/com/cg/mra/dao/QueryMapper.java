package com.cg.mra.dao;

public interface QueryMapper {

	public static final String SELECT_DETAILS_QUERY="select  * from accounts where account_id=?";
	public static final String UPDATE_BALANCE="UPDATE ACCOUNTS SET  ACCOUNT_BALANCE=ACCOUNT_BALANCE+? WHERE ACCOUNT_ID=?";
}
