package com.cg.mra.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBUtil {

	private static Connection connection;


	public static Connection getConnection() {

		FileReader reader;
		if (connection == null)
			try {
				reader = new FileReader("resources\\jdbc.properties");
				Properties properties = new Properties();
				properties.load(reader);
				Class.forName(properties.getProperty("driver"));
				connection = DriverManager.getConnection(
						properties.getProperty("url"),
						properties.getProperty("userName"),
						properties.getProperty("password"));
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		return connection;
	}

	public static void main(String[] args) {
		System.out.println(DBUtil.getConnection());
		System.out.println("////////////////");
		System.out.println(DBUtil.getConnection());
	}
}
